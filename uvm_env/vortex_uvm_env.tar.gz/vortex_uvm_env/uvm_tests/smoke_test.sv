`ifndef SMOKE_TEST_SV
`define SMOKE_TEST_SV

class smoke_test extends vortex_base_test;

  `uvm_component_utils(smoke_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    vortex_base_sequence seq = vortex_base_sequence::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(m_env.m_dcr_agent.m_sequencer); // Example: start on DCR sequencer
    phase.drop_objection(this);
  endtask

endclass : smoke_test

`endif // SMOKE_TEST_SV
