`ifndef VORTEX_BASE_TEST_SV
`define VORTEX_BASE_TEST_SV

class vortex_base_test extends uvm_test;

  `uvm_component_utils(vortex_base_test)

  vortex_env m_env;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_env = vortex_env::type_id::create("m_env", this);
  endfunction

endclass : vortex_base_test

`endif // VORTEX_BASE_TEST_SV
