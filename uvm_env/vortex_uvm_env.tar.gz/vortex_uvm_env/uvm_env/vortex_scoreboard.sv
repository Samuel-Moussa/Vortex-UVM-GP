`ifndef VORTEX_SCOREBOARD_SV
`define VORTEX_SCOREBOARD_SV

`include "simx_wrapper.sv"

class vortex_scoreboard extends uvm_scoreboard;

  `uvm_component_utils(vortex_scoreboard)

  // Analysis exports for all agents
  uvm_analysis_imp #(mem_transaction, vortex_scoreboard) mem_export;
  uvm_analysis_imp #(axi_transaction, vortex_scoreboard) axi_export;
  uvm_analysis_imp #(dcr_transaction, vortex_scoreboard) dcr_export;
  uvm_analysis_imp #(host_transaction, vortex_scoreboard) host_export;

  // Queues to store expected and actual transactions
  mem_transaction expected_mem_q[$];
  mem_transaction actual_mem_q[$];

  // simx wrapper instance
  simx_wrapper m_simx_wrapper;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mem_export = new("mem_export", this);
    axi_export = new("axi_export", this);
    dcr_export = new("dcr_export", this);
    host_export = new("host_export", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_simx_wrapper = new();
    m_simx_wrapper.simx_init();
  endfunction

  function void final_phase(uvm_phase phase);
    super.final_phase(phase);
    m_simx_wrapper.simx_shutdown();
  endfunction

  // Write functions for each agent's analysis port

  virtual function void write_mem(mem_transaction trans);
    `uvm_info("SCOREBOARD", "Received memory transaction from DUT", UVM_LOW)
    actual_mem_q.push_back(trans);
  endfunction

  virtual function void write_axi(axi_transaction trans);
    `uvm_info("SCOREBOARD", "Received AXI transaction from DUT", UVM_LOW)
    // Convert AXI transaction to memory transaction and push to actual_mem_q
  endfunction

  virtual function void write_dcr(dcr_transaction trans);
    `uvm_info("SCOREBOARD", "Received DCR transaction from DUT", UVM_LOW)
    // Pass DCR writes to the reference model
    m_simx_wrapper.simx_write_dcr(trans.addr, trans.data);
  endfunction

  virtual function void write_host(host_transaction trans);
    `uvm_info("SCOREBOARD", "Received host transaction from DUT", UVM_LOW)
    // Trigger kernel execution in the reference model
    m_simx_wrapper.simx_execute_kernel(trans.kernel_addr, trans.num_warps, trans.num_threads);
    // The reference model would then generate expected memory transactions
    // and push them to the expected_mem_q
  endfunction

  // Main scoreboard comparison logic
  virtual task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (actual_mem_q.size() > 0 && expected_mem_q.size() > 0) begin
        mem_transaction act_trans = actual_mem_q.pop_front();
        mem_transaction exp_trans = expected_mem_q.pop_front();
        if (!act_trans.compare(exp_trans)) begin
          `uvm_error("SCOREBOARD", "Memory transaction mismatch!")
          $display("Expected: %s", exp_trans.sprint());
          $display("Actual:   %s", act_trans.sprint());
        end
      end
    end
  endtask

endclass : vortex_scoreboard

`endif // VORTEX_SCOREBOARD_SV
