`ifndef HOST_DRIVER_SV
`define HOST_DRIVER_SV

class host_driver extends uvm_driver #(host_transaction);

  virtual vortex_if vif;
  dcr_sequencer m_dcr_sequencer;

  `uvm_component_utils(host_driver)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
    // Get the DCR sequencer handle from the config DB
    if (!uvm_config_db#(dcr_sequencer)::get(this, "", "m_dcr_sequencer", m_dcr_sequencer))
      `uvm_fatal("NO_DCR_SEQUENCER", "DCR sequencer must be set for host_driver");
  endfunction

  virtual task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_kernel_launch(req);
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_kernel_launch(host_transaction trans);
    dcr_transaction dcr_trans;
    `uvm_info("HOST_DRIVER", "Launching kernel", UVM_LOW)

    // Set number of warps
    dcr_trans = dcr_transaction::type_id::create("dcr_trans");
    dcr_trans.addr = `DCR_WARPS_ADDR; // Assumed DCR address
    dcr_trans.data = trans.num_warps;
    dcr_trans.start(m_dcr_sequencer);

    // Set number of threads
    dcr_trans = dcr_transaction::type_id::create("dcr_trans");
    dcr_trans.addr = `DCR_THREADS_ADDR; // Assumed DCR address
    dcr_trans.data = trans.num_threads;
    dcr_trans.start(m_dcr_sequencer);

    // Set kernel address
    dcr_trans = dcr_transaction::type_id::create("dcr_trans");
    dcr_trans.addr = `DCR_KERNEL_ADDR; // Assumed DCR address
    dcr_trans.data = trans.kernel_addr[31:0];
    dcr_trans.start(m_dcr_sequencer);

    // Start kernel execution
    dcr_trans = dcr_transaction::type_id::create("dcr_trans");
    dcr_trans.addr = `DCR_START_ADDR; // Assumed DCR address
    dcr_trans.data = 1;
    dcr_trans.start(m_dcr_sequencer);
  endtask

endclass : host_driver

`endif // HOST_DRIVER_SV
