`ifndef HOST_TRANSACTION_SV
`define HOST_TRANSACTION_SV

class host_transaction extends uvm_sequence_item;

  // Kernel launch command
  rand bit [63:0] kernel_addr;
  rand int unsigned num_warps;
  rand int unsigned num_threads;

  `uvm_object_utils_begin(host_transaction)
    `uvm_field_int(kernel_addr, UVM_ALL_ON)
    `uvm_field_int(num_warps, UVM_ALL_ON)
    `uvm_field_int(num_threads, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "host_transaction");
    super.new(name);
  endfunction

endclass : host_transaction

`endif // HOST_TRANSACTION_SV
