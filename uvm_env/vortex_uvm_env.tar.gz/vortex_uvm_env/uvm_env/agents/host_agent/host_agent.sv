`ifndef HOST_AGENT_SV
`define HOST_AGENT_SV

class host_agent extends uvm_agent;

  host_sequencer m_sequencer;
  host_driver m_driver;
  host_monitor m_monitor;

  `uvm_component_utils(host_agent)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_monitor = host_monitor::type_id::create("m_monitor", this);
    if (is_active == UVM_ACTIVE) begin
      m_driver = host_driver::type_id::create("m_driver", this);
      m_sequencer = host_sequencer::type_id::create("m_sequencer", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    if (is_active == UVM_ACTIVE) begin
      m_driver.seq_item_port.connect(m_sequencer.seq_item_export);
    end
  endfunction

endclass : host_agent

`endif // HOST_AGENT_SV
