`ifndef HOST_AGENT_PKG_SV
`define HOST_AGENT_PKG_SV

package host_agent_pkg;
  import uvm_pkg::*;

  `include "host_transaction.sv"
  `include "host_sequencer.sv"
  `include "host_driver.sv"
  `include "host_monitor.sv"
  `include "host_agent.sv"

endpackage : host_agent_pkg

`endif // HOST_AGENT_PKG_SV
