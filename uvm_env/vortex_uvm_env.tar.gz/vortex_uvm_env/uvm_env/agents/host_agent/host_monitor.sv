`ifndef HOST_MONITOR_SV
`define HOST_MONITOR_SV

class host_monitor extends uvm_monitor;

  virtual vortex_if vif;
  uvm_analysis_port #(host_transaction) item_collected_port;

  `uvm_component_utils(host_monitor)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    // Monitor DCR writes to detect kernel launch
    forever @(posedge vif.clk);
  endtask

endclass : host_monitor

`endif // HOST_MONITOR_SV
