`ifndef HOST_SEQUENCER_SV
`define HOST_SEQUENCER_SV

class host_sequencer extends uvm_sequencer #(host_transaction);

  `uvm_component_utils(host_sequencer)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass : host_sequencer

`endif // HOST_SEQUENCER_SV
