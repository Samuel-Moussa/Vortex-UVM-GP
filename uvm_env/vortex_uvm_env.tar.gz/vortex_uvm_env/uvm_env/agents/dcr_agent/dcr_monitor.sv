`ifndef DCR_MONITOR_SV
`define DCR_MONITOR_SV

class dcr_monitor extends uvm_monitor;

  virtual vortex_if vif;
  uvm_analysis_port #(dcr_transaction) item_collected_port;

  `uvm_component_utils(dcr_monitor)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    dcr_transaction trans;
    forever begin
      @(posedge vif.clk);
      if (vif.dcr_wr_valid) begin
        trans = dcr_transaction::type_id::create("trans");
        trans.addr = vif.dcr_wr_addr;
        trans.data = vif.dcr_wr_data;
        item_collected_port.write(trans);
      end
    end
  endtask

endclass : dcr_monitor

`endif // DCR_MONITOR_SV
