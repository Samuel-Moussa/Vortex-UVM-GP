`ifndef DCR_SEQUENCER_SV
`define DCR_SEQUENCER_SV

class dcr_sequencer extends uvm_sequencer #(dcr_transaction);

  `uvm_component_utils(dcr_sequencer)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass : dcr_sequencer

`endif // DCR_SEQUENCER_SV
