`ifndef DCR_TRANSACTION_SV
`define DCR_TRANSACTION_SV

class dcr_transaction extends uvm_sequence_item;

  rand bit [31:0] addr;
  rand bit [31:0] data;

  `uvm_object_utils_begin(dcr_transaction)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "dcr_transaction");
    super.new(name);
  endfunction

endclass : dcr_transaction

`endif // DCR_TRANSACTION_SV
