`ifndef DCR_AGENT_SV
`define DCR_AGENT_SV

class dcr_agent extends uvm_agent;

  dcr_sequencer m_sequencer;
  dcr_driver m_driver;
  dcr_monitor m_monitor;

  `uvm_component_utils(dcr_agent)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_monitor = dcr_monitor::type_id::create("m_monitor", this);
    if (is_active == UVM_ACTIVE) begin
      m_driver = dcr_driver::type_id::create("m_driver", this);
      m_sequencer = dcr_sequencer::type_id::create("m_sequencer", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    if (is_active == UVM_ACTIVE) begin
      m_driver.seq_item_port.connect(m_sequencer.seq_item_export);
    end
  endfunction

endclass : dcr_agent

`endif // DCR_AGENT_SV
