`ifndef DCR_AGENT_PKG_SV
`define DCR_AGENT_PKG_SV

package dcr_agent_pkg;
  import uvm_pkg::*;

  `include "dcr_transaction.sv"
  `include "dcr_sequencer.sv"
  `include "dcr_driver.sv"
  `include "dcr_monitor.sv"
  `include "dcr_agent.sv"

endpackage : dcr_agent_pkg

`endif // DCR_AGENT_PKG_SV
