
`ifndef DCR_DRIVER_SV
`define DCR_DRIVER_SV

class dcr_driver extends uvm_driver #(dcr_transaction);

  virtual vortex_if vif;

  `uvm_component_utils(dcr_driver)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_transfer(req);
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_transfer(dcr_transaction trans);
    vif.dcr_wr_valid <= 1'b1;
    vif.dcr_wr_addr  <= trans.addr;
    vif.dcr_wr_data  <= trans.data;
    @(posedge vif.clk);
    vif.dcr_wr_valid <= 1'b0;
  endtask

endclass : dcr_driver

`endif // DCR_DRIVER_SV
