
`ifndef AXI_TRANSACTION_SV
`define AXI_TRANSACTION_SV

class axi_transaction extends uvm_sequence_item;

  // AXI transaction type
  typedef enum {READ, WRITE} axi_txn_type_e;
  rand axi_txn_type_e txn_type;

  // Address Channel
  rand bit [63:0]    addr;
  rand bit [7:0]     len;
  rand bit [2:0]     size;
  rand bit [1:0]     burst;

  // Write Data Channel
  rand bit [511:0]   wdata[];

  // Read Data Channel
  bit [511:0]    rdata[];

  `uvm_object_utils_begin(axi_transaction)
    `uvm_field_enum(axi_txn_type_e, txn_type, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(len, UVM_ALL_ON)
    `uvm_field_int(size, UVM_ALL_ON)
    `uvm_field_int(burst, UVM_ALL_ON)
    `uvm_field_array_int(wdata, UVM_ALL_ON)
    `uvm_field_array_int(rdata, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "axi_transaction");
    super.new(name);
  endfunction

endclass : axi_transaction

`endif // AXI_TRANSACTION_SV
