`ifndef AXI_AGENT_SV
`define AXI_AGENT_SV

class axi_agent extends uvm_agent;

  axi_sequencer m_sequencer;
  axi_driver m_driver;
  axi_monitor m_monitor;

  `uvm_component_utils(axi_agent)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_monitor = axi_monitor::type_id::create("m_monitor", this);
    if (is_active == UVM_ACTIVE) begin
      m_driver = axi_driver::type_id::create("m_driver", this);
      m_sequencer = axi_sequencer::type_id::create("m_sequencer", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    if (is_active == UVM_ACTIVE) begin
      m_driver.seq_item_port.connect(m_sequencer.seq_item_export);
    end
  endfunction

endclass : axi_agent

`endif // AXI_AGENT_SV
