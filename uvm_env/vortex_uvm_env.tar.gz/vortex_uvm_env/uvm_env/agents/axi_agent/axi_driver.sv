`ifndef AXI_DRIVER_SV
`define AXI_DRIVER_SV

class axi_driver extends uvm_driver #(axi_transaction);

  virtual vortex_if vif;

  `uvm_component_utils(axi_driver)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_transfer(req);
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_transfer(axi_transaction trans);
    if (trans.txn_type == axi_transaction::WRITE) begin
      drive_write(trans);
    end else begin
      drive_read(trans);
    end
  endtask

  virtual task drive_write(axi_transaction trans);
    // Drive AW channel
    vif.m_axi_awvalid <= 1'b1;
    vif.m_axi_awaddr  <= trans.addr;
    vif.m_axi_awlen   <= trans.len;
    vif.m_axi_awsize  <= trans.size;
    vif.m_axi_awburst <= trans.burst;
    @(posedge vif.clk);
    while(!vif.m_axi_awready)
      @(posedge vif.clk);
    vif.m_axi_awvalid <= 1'b0;

    // Drive W channel
    for (int i = 0; i <= trans.len; i++) begin
      vif.m_axi_wvalid <= 1'b1;
      vif.m_axi_wdata  <= trans.wdata[i];
      vif.m_axi_wstrb  <= '1;
      vif.m_axi_wlast  <= (i == trans.len);
      @(posedge vif.clk);
      while(!vif.m_axi_wready)
        @(posedge vif.clk);
    end
    vif.m_axi_wvalid <= 1'b0;

    // Wait for B channel
    vif.m_axi_bready <= 1'b1;
    @(posedge vif.clk);
    while(!vif.m_axi_bvalid)
      @(posedge vif.clk);
    vif.m_axi_bready <= 1'b0;
  endtask

  virtual task drive_read(axi_transaction trans);
    // Drive AR channel
    vif.m_axi_arvalid <= 1'b1;
    vif.m_axi_araddr  <= trans.addr;
    vif.m_axi_arlen   <= trans.len;
    vif.m_axi_arsize  <= trans.size;
    vif.m_axi_arburst <= trans.burst;
    @(posedge vif.clk);
    while(!vif.m_axi_arready)
      @(posedge vif.clk);
    vif.m_axi_arvalid <= 1'b0;

    // Wait for R channel
    trans.rdata.delete();
    for (int i = 0; i <= trans.len; i++) begin
      vif.m_axi_rready <= 1'b1;
      @(posedge vif.clk);
      while(!vif.m_axi_rvalid)
        @(posedge vif.clk);
      trans.rdata.push_back(vif.m_axi_rdata);
    end
    vif.m_axi_rready <= 1'b0;
  endtask

endclass : axi_driver

`endif // AXI_DRIVER_SV
