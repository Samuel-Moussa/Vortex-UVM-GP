`ifndef AXI_AGENT_PKG_SV
`define AXI_AGENT_PKG_SV

package axi_agent_pkg;
  import uvm_pkg::*;

  `include "axi_transaction.sv"
  `include "axi_sequencer.sv"
  `include "axi_driver.sv"
  `include "axi_monitor.sv"
  `include "axi_agent.sv"

endpackage : axi_agent_pkg

`endif // AXI_AGENT_PKG_SV
