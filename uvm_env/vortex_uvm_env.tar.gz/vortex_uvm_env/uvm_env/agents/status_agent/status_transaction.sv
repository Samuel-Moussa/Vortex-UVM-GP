`ifndef STATUS_TRANSACTION_SV
`define STATUS_TRANSACTION_SV

class status_transaction extends uvm_sequence_item;

  bit busy;

  `uvm_object_utils_begin(status_transaction)
    `uvm_field_int(busy, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "status_transaction");
    super.new(name);
  endfunction

endclass : status_transaction

`endif // STATUS_TRANSACTION_SV
