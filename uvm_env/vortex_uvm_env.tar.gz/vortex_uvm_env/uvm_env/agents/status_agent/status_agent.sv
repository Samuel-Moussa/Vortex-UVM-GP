`ifndef STATUS_AGENT_SV
`define STATUS_AGENT_SV

class status_agent extends uvm_agent;

  status_monitor m_monitor;

  `uvm_component_utils(status_agent)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // This is a passive agent, so no driver or sequencer
    m_monitor = status_monitor::type_id::create("m_monitor", this);
  endfunction

endclass : status_agent

`endif // STATUS_AGENT_SV
