`ifndef STATUS_AGENT_PKG_SV
`define STATUS_AGENT_PKG_SV

package status_agent_pkg;
  import uvm_pkg::*;

  `include "status_transaction.sv"
  `include "status_monitor.sv"
  `include "status_agent.sv"

endpackage : status_agent_pkg

`endif // STATUS_AGENT_PKG_SV
