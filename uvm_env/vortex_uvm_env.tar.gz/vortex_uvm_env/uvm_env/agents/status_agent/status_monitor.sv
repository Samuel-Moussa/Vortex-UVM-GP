`ifndef STATUS_MONITOR_SV
`define STATUS_MONITOR_SV

class status_monitor extends uvm_monitor;

  virtual vortex_if vif;
  uvm_analysis_port #(status_transaction) item_collected_port;

  `uvm_component_utils(status_monitor)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    status_transaction trans;
    forever begin
      @(posedge vif.clk);
      trans = status_transaction::type_id::create("trans");
      trans.busy = vif.busy;
      item_collected_port.write(trans);
    end
  endtask

endclass : status_monitor

`endif // STATUS_MONITOR_SV
