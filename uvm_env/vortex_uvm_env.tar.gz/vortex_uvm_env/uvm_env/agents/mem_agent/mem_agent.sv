`ifndef MEM_AGENT_SV
`define MEM_AGENT_SV

class mem_agent extends uvm_agent;

  mem_sequencer m_sequencer;
  mem_driver m_driver;
  mem_monitor m_monitor;

  `uvm_component_utils(mem_agent)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_monitor = mem_monitor::type_id::create(
"m_monitor", this);
    if (is_active == UVM_ACTIVE) begin
      m_driver = mem_driver::type_id::create(
"m_driver", this);
      m_sequencer = mem_sequencer::type_id::create(
"m_sequencer", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    if (is_active == UVM_ACTIVE) begin
      m_driver.seq_item_port.connect(m_sequencer.seq_item_export);
    end
  endfunction

endclass : mem_agent

`endif // MEM_AGENT_SV
