`ifndef MEM_AGENT_PKG_SV
`define MEM_AGENT_PKG_SV

package mem_agent_pkg;
  import uvm_pkg::*;

  `include "mem_transaction.sv"
  `include "mem_sequencer.sv"
  `include "mem_driver.sv"
  `include "mem_monitor.sv"
  `include "mem_agent.sv"

endpackage : mem_agent_pkg

`endif // MEM_AGENT_PKG_SV
