`ifndef MEM_TRANSACTION_SV
`define MEM_TRANSACTION_SV

class mem_transaction extends uvm_sequence_item;

  // Request fields
  rand bit                  rw;
  rand bit [63:0]           addr;
  rand bit [511:0]          data; // Assuming 512-bit data width
  rand bit [63:0]           byteen; // Assuming 64-bit byteen

  // Response fields
  bit [511:0]          rsp_data;

  `uvm_object_utils_begin(mem_transaction)
    `uvm_field_int(rw, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(byteen, UVM_ALL_ON)
    `uvm_field_int(rsp_data, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "mem_transaction");
    super.new(name);
  endfunction

endclass : mem_transaction

`endif // MEM_TRANSACTION_SV
