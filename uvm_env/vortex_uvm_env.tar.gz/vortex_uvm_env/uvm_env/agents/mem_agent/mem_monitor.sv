
`ifndef MEM_MONITOR_SV
`define MEM_MONITOR_SV

class mem_monitor extends uvm_monitor;

  virtual vortex_if vif;
  uvm_analysis_port #(mem_transaction) item_collected_port;

  `uvm_component_utils(mem_monitor)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    mem_transaction trans;
    forever begin
      @(posedge vif.clk);
      if (vif.mem_req_valid && vif.mem_req_ready) begin
        trans = mem_transaction::type_id::create("trans");
        trans.rw = vif.mem_req_rw;
        trans.addr = vif.mem_req_addr;
        trans.byteen = vif.mem_req_byteen;
        if (trans.rw) begin // Write
          trans.data = vif.mem_req_data;
        end
        // For reads, the response data will be collected separately
        item_collected_port.write(trans);
      end
      if(vif.mem_rsp_valid && vif.mem_rsp_ready) begin
        // This is a simplified monitor. A more robust monitor would match response to request.
        trans = mem_transaction::type_id::create("trans");
        trans.rw = 0; // It's a read response
        trans.rsp_data = vif.mem_rsp_data;
        item_collected_port.write(trans);
      end
    end
  endtask

endclass : mem_monitor

`endif // MEM_MONITOR_SV
