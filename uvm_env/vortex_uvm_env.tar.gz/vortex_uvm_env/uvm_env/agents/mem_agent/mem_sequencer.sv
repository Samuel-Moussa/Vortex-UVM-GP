`ifndef MEM_SEQUENCER_SV
`define MEM_SEQUENCER_SV

class mem_sequencer extends uvm_sequencer #(mem_transaction);

  `uvm_component_utils(mem_sequencer)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass : mem_sequencer

`endif // MEM_SEQUENCER_SV
