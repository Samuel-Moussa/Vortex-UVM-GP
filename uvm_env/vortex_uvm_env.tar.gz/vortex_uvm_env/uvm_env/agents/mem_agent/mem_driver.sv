`ifndef MEM_DRIVER_SV
`define MEM_DRIVER_SV

class mem_driver extends uvm_driver #(mem_transaction);

  virtual vortex_if vif;

  `uvm_component_utils(mem_driver)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vortex_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", {"Virtual interface must be set for: ", get_full_name(), ".vif"});
  endfunction

  virtual task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_transfer(req);
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_transfer(mem_transaction trans);
    vif.mem_req_valid <= 1'b1;
    vif.mem_req_rw    <= trans.rw;
    vif.mem_req_addr  <= trans.addr;
    vif.mem_req_byteen <= trans.byteen;
    if (trans.rw) begin // Write
      vif.mem_req_data <= trans.data;
    end

    @(posedge vif.clk);
    while (!vif.mem_req_ready)
      @(posedge vif.clk);

    vif.mem_req_valid <= 1'b0;

    if (!trans.rw) begin // Read
      // Wait for response
      @(posedge vif.clk);
      while(!vif.mem_rsp_valid)
        @(posedge vif.clk);
      trans.rsp_data = vif.mem_rsp_data;
    end

  endtask

endclass : mem_driver

`endif // MEM_DRIVER_SV
