`ifndef VORTEX_ENV_SV
`define VORTEX_ENV_SV

class vortex_env extends uvm_env;

  `uvm_component_utils(vortex_env)

  mem_agent m_mem_agent;
  axi_agent m_axi_agent;
  dcr_agent m_dcr_agent;
  vortex_scoreboard m_scoreboard;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    m_mem_agent = mem_agent::type_id::create("m_mem_agent", this);
    m_axi_agent = axi_agent::type_id::create("m_axi_agent", this);
    m_dcr_agent = dcr_agent::type_id::create("m_dcr_agent", this);
    m_scoreboard = vortex_scoreboard::type_id::create("m_scoreboard", this);
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    m_mem_agent.m_monitor.item_collected_port.connect(m_scoreboard.mem_export);
    // Connect other agents to the scoreboard as well
  endfunction

endclass : vortex_env

`endif // VORTEX_ENV_SV
