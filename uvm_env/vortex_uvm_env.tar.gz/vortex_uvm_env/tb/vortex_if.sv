`ifndef VORTEX_IF_SV
`define VORTEX_IF_SV

interface vortex_if(input wire clk, input wire reset);

  // Memory request
  logic                             mem_req_valid;
  logic                             mem_req_rw;
  logic [`VX_MEM_BYTEEN_WIDTH-1:0]  mem_req_byteen;
  logic [`VX_MEM_ADDR_WIDTH-1:0]    mem_req_addr;
  logic [`VX_MEM_DATA_WIDTH-1:0]    mem_req_data;
  logic [`VX_MEM_TAG_WIDTH-1:0]     mem_req_tag;
  logic                             mem_req_ready;

  // Memory response
  logic                              mem_rsp_valid;
  logic [`VX_MEM_DATA_WIDTH-1:0]     mem_rsp_data;
  logic [`VX_MEM_TAG_WIDTH-1:0]      mem_rsp_tag;
  logic                             mem_rsp_ready;

  // DCR write request
  logic                             dcr_wr_valid;
  logic [`VX_DCR_ADDR_WIDTH-1:0]    dcr_wr_addr;
  logic [`VX_DCR_DATA_WIDTH-1:0]    dcr_wr_data;

  // Status
  logic                             busy;

  // AXI signals would also be included here for the AXI wrapper
  // ...

endinterface : vortex_if

`endif // VORTEX_IF_SV
