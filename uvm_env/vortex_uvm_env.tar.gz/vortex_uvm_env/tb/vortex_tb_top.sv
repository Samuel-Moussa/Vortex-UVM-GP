`ifndef VORTEX_TB_TOP_SV
`define VORTEX_TB_TOP_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
`include "vortex_test_pkg.sv"

module vortex_tb_top;

  bit clk;
  bit reset;

  // Clock generation
  always #5 clk = ~clk;

  // Reset generation
  initial begin
    clk = 0;
    reset = 1;
    #20 reset = 0;
  end

  // Instantiate the interface
  vortex_if vif(clk, reset);

  // Instantiate the DUT
  Vortex dut (
    .clk(clk),
    .reset(reset),
    .mem_req_valid(vif.mem_req_valid),
    .mem_req_rw(vif.mem_req_rw),
    .mem_req_byteen(vif.mem_req_byteen),
    .mem_req_addr(vif.mem_req_addr),
    .mem_req_data(vif.mem_req_data),
    .mem_req_tag(vif.mem_req_tag),
    .mem_req_ready(vif.mem_req_ready),
    .mem_rsp_valid(vif.mem_rsp_valid),
    .mem_rsp_data(vif.mem_rsp_data),
    .mem_rsp_tag(vif.mem_rsp_tag),
    .mem_rsp_ready(vif.mem_rsp_ready),
    .dcr_wr_valid(vif.dcr_wr_valid),
    .dcr_wr_addr(vif.dcr_wr_addr),
    .dcr_wr_data(vif.dcr_wr_data),
    .busy(vif.busy)
  );

  // UVM test harness
  initial begin
    uvm_config_db#(virtual vortex_if)::set(null, "uvm_test_top", "vif", vif);
    run_test();
  end

endmodule : vortex_tb_top

`endif // VORTEX_TB_TOP_SV
