arXiv submission package - single self-contained main.tex
(inline TikZ figures, inline thebibliography; standard TeX Live packages only).
Compile: pdflatex main.tex (run twice).
